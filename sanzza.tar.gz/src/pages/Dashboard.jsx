import { Card, CardContent } from "../components/ui/card";

export default function Dashboard() {
  return (
    <Card>
      <CardContent>
        <h1 className="text-xl font-bold mb-4">Servicios en curso</h1>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="bg-gray-200">
              <tr>
                <th className="text-left p-2">ID</th>
                <th className="text-left p-2">Ubicación</th>
                <th className="text-left p-2">Estado</th>
                <th className="text-left p-2">Hora de arribo</th>
                <th className="text-left p-2">Finalización estimada</th>
              </tr>
            </thead>
            <tbody>
              <tr className="border-t">
                <td className="p-2">#001</td>
                <td className="p-2">Pozo 32</td>
                <td className="p-2">En curso</td>
                <td className="p-2">11:30</td>
                <td className="p-2">13:00</td>
              </tr>
            </tbody>
          </table>
        </div>
      </CardContent>
    </Card>
  );
}