import { Link } from "react-router-dom";
import { Bell, Plus } from "lucide-react";
import { Button } from "./ui/button";

export default function Header() {
  return (
    <header className="flex items-center justify-between px-6 py-3 shadow-md bg-white">
      <nav className="flex gap-6 text-sm font-semibold text-gray-700">
        <Link to="/" className="hover:text-blue-600">Principal</Link>
        <Link to="/pendientes" className="hover:text-blue-600">Servicios</Link>
        <Link to="/alertas" className="hover:text-blue-600">Alertas</Link>
      </nav>
      <div className="flex items-center gap-4">
        <Button variant="ghost" className="relative p-2">
          <Bell className="w-5 h-5" />
          <span className="absolute -top-1 -right-1 bg-red-500 text-white text-xs rounded-full px-1">3</span>
        </Button>
        <Button variant="outline" size="sm">
          <Plus className="w-4 h-4 mr-1" /> Nuevo Servicio
        </Button>
        <img src="/logo.png" alt="Logo" className="h-8" />
      </div>
    </header>
  );
}